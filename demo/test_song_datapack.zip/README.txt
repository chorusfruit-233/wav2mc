Run /function test_song:start as a player to begin.
Run /function test_song:stop to stop.
Install and enable the matching wav2mc hybrid resource pack first.
