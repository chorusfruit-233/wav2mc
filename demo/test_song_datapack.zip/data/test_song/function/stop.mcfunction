scoreboard players set #playing wav2mc 0
stopsound @a[tag=wav2mc_listener] record
tag @a remove wav2mc_listener
scoreboard players set #frame wav2mc 0
