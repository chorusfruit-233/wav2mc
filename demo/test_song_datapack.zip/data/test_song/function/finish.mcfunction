scoreboard players set #playing wav2mc 0
scoreboard players set #frame wav2mc 0
tag @a remove wav2mc_listener
