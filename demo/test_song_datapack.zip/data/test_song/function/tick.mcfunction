execute if score #playing wav2mc matches 1 run function test_song:dispatch/root
execute if score #playing wav2mc matches 1 run scoreboard players add #frame wav2mc 1
execute if score #frame wav2mc matches 79.. run function test_song:finish
