tag @a remove wav2mc_listener
tag @s add wav2mc_listener
scoreboard players set #frame wav2mc 0
scoreboard players set #playing wav2mc 1
tellraw @s {"text":"Playing test_song","color":"green"}
