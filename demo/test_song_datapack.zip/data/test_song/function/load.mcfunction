scoreboard objectives add wav2mc dummy
scoreboard players set #playing wav2mc 0
scoreboard players set #frame wav2mc 0
