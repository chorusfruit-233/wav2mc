execute as @a[tag=wav2mc_listener] at @s run playsound wav2mc:grain.f0440.p03 record @s ~ ~ ~ 0.305900 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s run playsound wav2mc:grain.f0660.p03 record @s ~ ~ ~ 0.146965 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s run playsound wav2mc:grain.f0880.p03 record @s ~ ~ ~ 0.058094 1.0 0.0
