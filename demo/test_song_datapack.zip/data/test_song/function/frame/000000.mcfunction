execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0440.p03 record @s ~ ~ ~ 0.486934 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0660.p03 record @s ~ ~ ~ 0.234077 0.99997766 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0880.p03 record @s ~ ~ ~ 0.092563 0.99997287 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:transient.b03.v03 record @s ~ ~ ~ 0.241388 1.0 0.0
