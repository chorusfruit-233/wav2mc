execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0440.p03 record @s ~ ~ ~ 0.480679 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0660.p03 record @s ~ ~ ~ 0.231070 0.99997766 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0880.p03 record @s ~ ~ ~ 0.091374 0.99997287 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:transient.b03.v03.d25.slow record @s ~ ~ ~ 0.044550 1.0 0.0
