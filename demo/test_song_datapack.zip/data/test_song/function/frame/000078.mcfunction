execute as @a[tag=wav2mc_listener] at @s run playsound wav2mc:grain.f0440.p03 record @s ~ ~ ~ 0.310211 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s run playsound wav2mc:grain.f0660.p03 record @s ~ ~ ~ 0.148484 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s run playsound wav2mc:grain.f0880.p03 record @s ~ ~ ~ 0.058560 1.0 0.0
