execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0440.p03 record @s ~ ~ ~ 0.493526 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0660.p03 record @s ~ ~ ~ 0.236399 0.99997781 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0880.p03 record @s ~ ~ ~ 0.093278 0.99997130 0.0
