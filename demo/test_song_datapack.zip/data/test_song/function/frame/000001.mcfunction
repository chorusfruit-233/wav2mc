execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0440.p03 record @s ~ ~ ~ 0.568431 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0660.p03 record @s ~ ~ ~ 0.272644 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0880.p03 record @s ~ ~ ~ 0.107690 1.0 0.0
