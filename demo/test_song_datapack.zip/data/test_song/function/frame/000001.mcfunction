execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0440.p03 record @s ~ ~ ~ 0.575829 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0660.p03 record @s ~ ~ ~ 0.276193 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s anchored eyes run playsound wav2mc:grain.f0880.p03 record @s ~ ~ ~ 0.109092 1.0 0.0
