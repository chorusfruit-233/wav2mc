execute as @a[tag=wav2mc_listener] at @s run playsound wav2mc:grain.f0440.p03 record @s ~ ~ ~ 0.376407 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s run playsound wav2mc:grain.f0660.p03 record @s ~ ~ ~ 0.180366 1.0 0.0
execute as @a[tag=wav2mc_listener] at @s run playsound wav2mc:grain.f0880.p03 record @s ~ ~ ~ 0.071193 1.0 0.0
