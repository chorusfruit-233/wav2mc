execute if score #frame wav2mc matches 40..49 run function test_song:dispatch/n_000040_000049
execute if score #frame wav2mc matches 50..59 run function test_song:dispatch/n_000050_000059
