execute if score #frame wav2mc matches 20..29 run function test_song:dispatch/n_000020_000029
execute if score #frame wav2mc matches 30..39 run function test_song:dispatch/n_000030_000039
