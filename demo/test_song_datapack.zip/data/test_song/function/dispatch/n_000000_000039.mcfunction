execute if score #frame wav2mc matches 0..19 run function test_song:dispatch/n_000000_000019
execute if score #frame wav2mc matches 20..39 run function test_song:dispatch/n_000020_000039
