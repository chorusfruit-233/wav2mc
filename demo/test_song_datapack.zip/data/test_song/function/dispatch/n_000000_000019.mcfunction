execute if score #frame wav2mc matches 0..9 run function test_song:dispatch/n_000000_000009
execute if score #frame wav2mc matches 10..19 run function test_song:dispatch/n_000010_000019
