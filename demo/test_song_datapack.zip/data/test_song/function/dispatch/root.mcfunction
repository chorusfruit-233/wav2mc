execute if score #frame wav2mc matches 0..39 run function test_song:dispatch/n_000000_000039
execute if score #frame wav2mc matches 40..78 run function test_song:dispatch/n_000040_000078
