execute if score #frame wav2mc matches 60..69 run function test_song:dispatch/n_000060_000069
execute if score #frame wav2mc matches 70..78 run function test_song:dispatch/n_000070_000078
