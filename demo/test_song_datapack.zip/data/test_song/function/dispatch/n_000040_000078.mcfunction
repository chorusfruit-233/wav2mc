execute if score #frame wav2mc matches 40..59 run function test_song:dispatch/n_000040_000059
execute if score #frame wav2mc matches 60..78 run function test_song:dispatch/n_000060_000078
